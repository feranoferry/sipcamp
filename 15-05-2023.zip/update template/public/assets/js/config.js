
 
const firebaseConfig = {
    apiKey: "AIzaSyBR1ZNFfeZspwybsyd410kVHPQY3tlFyz0",
    authDomain: "sip-camp.firebaseapp.com",
    databaseURL: "https://sip-camp-default-rtdb.firebaseio.com",
    projectId: "sip-camp",
    storageBucket: "sip-camp.appspot.com",
    messagingSenderId: "1071374701717",
    appId: "1:1071374701717:web:3a5b14791eae153924379c",
    measurementId: "G-54Y46YML1D"
 };

const app = firebase.initializeApp(firebaseConfig);