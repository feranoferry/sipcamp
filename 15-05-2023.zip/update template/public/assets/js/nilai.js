const slot1 = document.getElementById("slot1");
const slot2 = document.getElementById("slot2");
const slot3 = document.getElementById("slot3");
const slot4 = document.getElementById("slot4");
const counter = document.getElementById("parking-counter");
const available = document.getElementById("parking-available");


firebase.database().ref("/").on("value", (data) => {
  const totalSlots = 4;
  let parkedCount = 0;

  for (let i = 1; i <= totalSlots; i++) {
    const slotData = data.val()["DATA_" + i]["Pembacaan Sensor"];

    if (slotData === 0) {
      parkedCount++;
    }
  }

  const availableCount = totalSlots - parkedCount;

  counter.textContent = "Kendaraan Terparkir " + parkedCount;
  available.textContent = "Status area Parkir " + availableCount + " Tersedia";
});




firebase.database().ref("DATA_1/Pembacaan Sensor").on("value", (data) => {

    if (data.val() == 0) {

        slot1.innerHTML = (`
       
        `)
        slot1B.style.backgroundColor = "#6feaf5";

    } else {

        slot1.innerHTML = (`
       
        `)
        slot1B.style.backgroundColor = "#01163e";

    };
});


firebase.database().ref("DATA_2/Pembacaan Sensor").on("value", (data) => {

    if (data.val() == 0) {

        slot2.innerHTML = (`
        
        `)
        slot2B.style.backgroundColor = "#6feaf5";

    } else {

        slot2.innerHTML = (`
        
        `)
        slot2B.style.backgroundColor = "#01163e";

    };
});

firebase.database().ref("DATA_3/Pembacaan Sensor").on("value", (data) => {

    if (data.val() == 0) {

        slot3.innerHTML = (`
        
        `)
        slot3B.style.backgroundColor = "#6feaf5";
        
    } else {

        slot3.innerHTML = (`
      
        `)
        slot3B.style.backgroundColor = "#01163e";
    };
});

firebase.database().ref("DATA_4/Pembacaan Sensor").on("value", (data) => {

    if (data.val() == 0) {

        slot4.innerHTML = (`
        
        
        `)
        slot4B.style.backgroundColor = "#6feaf5";

    } else {

        slot4.innerHTML = (`
       
        `)
        slot4B.style.backgroundColor = "#01163e";
    };
});

